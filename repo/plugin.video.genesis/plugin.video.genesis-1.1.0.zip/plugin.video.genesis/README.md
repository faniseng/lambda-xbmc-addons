======================
Genesis XBMC Addon
======================

About
-----
The origins of streaming


Attributions
---------------------
- GKDecrypter by shani_08 | http://www.xbmchub.com
- 4orbs theme by Marquerite | http://www.xbmchub.com
- Aztec theme by azad720 | http://www.xbmchub.com
- Embossed theme by jokster | http://www.xbmchub.com
- Portuguese translation by Mafarricos | http://www.xbmchub.com
- French translation by dr1ss | http://www.xbmchub.com


License
-------
This software is released under the [GPL 3.0 license] [1].
[1]: http://www.gnu.org/licenses/gpl-3.0.html